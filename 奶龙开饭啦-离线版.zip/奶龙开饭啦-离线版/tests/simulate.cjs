const fs=require('node:fs');
const C=require('../core.js');
const DT=1/60;
function normal(rng){return Math.sqrt(-2*Math.log(Math.max(1e-6,rng())))*Math.cos(2*Math.PI*rng());}
function rayTarget(g,angle){const d=C.rayBoundary(angle),x=500+Math.sin(angle)*d,y=138+Math.cos(angle)*d;let first=Infinity,hit=null;for(const i of g.items){const t=C.segmentHit(500,138,x,y,i);if(t!==null&&t<first){first=t;hit=i;}}return hit;}
function play(seed,error,speed){const rng=C.seededRandom(seed*997+13),g=new C.Game({rng:C.seededRandom(seed),speed});g.start();let selected=null,aim=null,shots=0,foods=0,bitters=0,misses=0,max=0;
 while(g.status==='running'){
  if(g.phase==='aim'){
   if(!selected){const options=g.items.filter(i=>i.type!=='bitter').map(i=>{const a=Math.atan2(i.x-500,i.y-138),dist=Math.hypot(i.x-500,i.y-138);let wait=(a-g.angle)*g.direction/C.CONFIG.swingSpeed;if(wait<0)wait=(2*(C.CONFIG.maxAngle-g.direction*g.angle)-Math.abs(a-g.angle))/C.CONFIG.swingSpeed;return{i,a,rank:C.TYPES[i.type].points/(Math.max(.05,wait)+2*dist/speed)};}).filter(o=>rayTarget(g,o.a)?.id===o.i.id).sort((a,b)=>b.rank-a.rank);if(options.length){selected=options[0].i;aim=options[0].a+normal(rng)*error;}else{selected={id:-1};aim=0;}}
   if(Math.abs(g.angle-aim)<C.CONFIG.swingSpeed*DT*1.1||Math.abs(aim)>C.CONFIG.maxAngle){g.fire();shots++;selected=null;aim=null;}
  }
  g.step(DT);for(const e of g.events.splice(0)){if(e.type==='eat')foods++;if(e.type==='bitter')bitters++;if(e.type==='miss')misses++;}max=g.elapsed;
 }
 return{win:g.status==='won',score:g.score,elapsed:max,shots,foods,bitters,misses};
}
const output=[];for(const error of [0,.02,.035,.055])for(const speed of [360,390]){const games=Array.from({length:300},(_,s)=>play(s,error,speed));const avg=k=>+(games.reduce((s,g)=>s+g[k],0)/games.length).toFixed(2);output.push({model:'visible-target priority bot; independent Gaussian angular error; not human data',angularErrorRadians:error,speed,seeds:300,winPercent:+(100*games.filter(g=>g.win).length/300).toFixed(1),score:avg('score'),attempts:avg('shots'),foods:avg('foods'),bitter:avg('bitters'),empty:avg('misses'),elapsed:avg('elapsed')});}
const layouts=Array.from({length:1000},(_,s)=>C.generateLayout(C.seededRandom(s))).flat();const avgDistance=layouts.reduce((s,i)=>s+Math.hypot(i.x-500,i.y-138),0)/layouts.length;
const report={date:'2026-10-08',meanDistanceVirtualPixels:+avgDistance.toFixed(1),limitations:'No human win-rate measurement. Bot selects visible high-value targets; these results do not validate the 70% human target.',results:output};fs.mkdirSync('output',{recursive:true});fs.writeFileSync('output/difficulty-simulation.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
