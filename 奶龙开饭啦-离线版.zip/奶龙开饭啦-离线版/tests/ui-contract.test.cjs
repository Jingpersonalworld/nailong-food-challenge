const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
for(const file of ['开始游戏.html','style.css','game.js']) assert.ok(fs.existsSync(path.join(root,file)),`${file} must exist`);
const html=fs.readFileSync(path.join(root,'开始游戏.html'),'utf8');
for(const id of ['game','start','pause','retry','sound','resume','home','paused','result','score','time','progress']) assert.ok(html.includes(`id="${id}"`),`missing UI ${id}`);
assert.ok(html.includes('45 秒美食大挑战'));
for(const file of ['开始游戏.html','style.css','game.js']) {
 const s=fs.readFileSync(path.join(root,file),'utf8');
 assert.ok(!/https?:\/\/|@import|fetch\(|type="module"|new WebSocket/.test(s),`remote / HTTP dependency in ${file}`);
}
console.log('PASS UI contract and static offline audit');
